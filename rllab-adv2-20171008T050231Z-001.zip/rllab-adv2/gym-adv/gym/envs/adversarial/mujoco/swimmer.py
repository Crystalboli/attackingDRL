import numpy as np
from numpy import linalg as LA
import math
from gym import utils, spaces
from gym.envs.adversarial.mujoco import mujoco_env


class SwimmerEnv(mujoco_env.MujocoEnv, utils.EzPickle):

    def __init__(self):
        mujoco_env.MujocoEnv.__init__(self, 'swimmer.xml', 4)
        utils.EzPickle.__init__(self)
        # Adversarial setup
        # Byte String name of body on which the adversary force will be applied
        self._adv_f_bname = b'torso'
        self.bnames = self.model.body_names
        # Index of the body on which the adversary force will be applied
        self._adv_bindex = self.bnames.index(self._adv_f_bname)
        """
        adv_max_force = 5.
        high_adv = np.ones(3) * adv_max_force
        low_adv = - high_adv
        self.adv_action_space = spaces.Box(low_adv, high_adv)
        """
        self.adv_action_space = self.action_space
        self.pro_action_space = self.action_space

    def env_setup(self, args=None):
        if args is not None:
            self.sim_step = 0
            self.ctrl_noise = args.ctrl_noise
            self.act_noise = args.act_noise
            self.state_noise = args.state_noise
            self.RARL = args.RARL
            self.epsilon = args.epsilon
            self.eps_grad = args.eps_grad
            self.para_a, self.para_b = args.eps_grad_paras
            # norm type: {1: l1, 2: l2, 3: inf}
            self.norm = args.norm
            if self.RARL:
                adv_max_force = 5.
                high_adv = np.ones(3) * adv_max_force
                low_adv = - high_adv
                self.adv_action_space = spaces.Box(low_adv, high_adv)
            elif self.act_noise:
                # The dimension of action space is [#body - 1, 3]
                # we just ignore the worldbody tag
                adv_max_force = 123456
                self.adv_act_space_dim = 3 * (len(self.bnames) - 1)
                high_adv = np.ones(self.adv_act_space_dim) * adv_max_force
                low_adv = - high_adv
                self.adv_action_space = spaces.Box(low_adv, high_adv)
            elif self.ctrl_noise:
                self.adv_act_space_dim = self.action_space.shape[0]
                self.adv_action_space = self.action_space
            elif self.state_noise:
                self.adv_act_space_dim = self.obs_dim
                self.adv_action_space = self.observation_space
            else:
                pass

    def _adv_to_xfrc(self, adv_act):
        # See reference here: http://www.mujoco.org/book/reference.html#mjData
        # It seems that the dimension of xfrc_applied is [#body, 6]
        # The 2nd dim is 6: force & torque
        new_xfrc = self.model.data.xfrc_applied * 0.0
        if self.act_noise:
            for i, bname in enumerate(self.bnames[1:]):
                new_xfrc[i + 1, :3] = adv_act[(i * 3):(i * 3 + 3)]
        else:
            new_xfrc[self._adv_bindex] = np.array(
                [adv_act[0], adv_act[1], adv_act[2], 0., 0., 0.])
        self.model.data.xfrc_applied = new_xfrc

    def sample_action(self):
        if self.eps_grad:
            self.sim_step = self.sim_step + 1
            self.epsilon =\
                self.para_a * math.log(self.sim_step, math.exp(1)) + self.para_b

        class act(object):
            def __init__(self, pro=None, adv=None):
                self.pro = pro
                self.adv = adv

        if self.act_noise:
            pre_sample_adv_act = np.random.normal(size=self.adv_act_space_dim)
            if self.norm == 1:
                sample_norm = LA.norm(pre_sample_adv_act, 1)
                sample_adv_act =\
                    self.epsilon * pre_sample_adv_act / (sample_norm + 1e-8)
            elif self.norm == 2:
                sample_norm = LA.norm(pre_sample_adv_act, 2)
                sample_adv_act =\
                    np.sqrt(self.epsilon) * pre_sample_adv_act / (sample_norm + 1e-8)
            elif self.norm == 3:
                sample_norm = LA.norm(pre_sample_adv_act, np.inf)
                if np.abs(sample_norm) > self.epsilon:
                    pre_sample_adv_act[np.where(np.abs(pre_sample_adv_act) == sample_norm)]\
                        = self.epsilon
                sample_adv_act = pre_sample_adv_act
            else:
                raise ValueError
        else:
            sample_adv_act = self.adv_action_space.sample()

        sa = act(self.pro_action_space.sample(), sample_adv_act)
        return sa

    def _step(self, action):
        if hasattr(action, '__dict__'):
            if self.act_noise or self.RARL:
                self._adv_to_xfrc(action.adv)
                a = action.pro
            elif self.ctrl_noise:
                a = action.pro + action.adv
            else:
                a = action.pro
        else:
            a = action

        ctrl_cost_coeff = 0.0001
        xposbefore = self.model.data.qpos[0, 0]
        self.do_simulation(a, self.frame_skip)
        xposafter = self.model.data.qpos[0, 0]
        reward_fwd = (xposafter - xposbefore) / self.dt
        reward_ctrl = - ctrl_cost_coeff * np.square(a).sum()
        reward = reward_fwd + reward_ctrl
        ob = self._get_obs()
        return ob, reward, False, dict(reward_fwd=reward_fwd, reward_ctrl=reward_ctrl)

    def _get_obs(self):
        qpos = self.model.data.qpos
        qvel = self.model.data.qvel
        return np.concatenate([qpos.flat[2:], qvel.flat])

    def reset_model(self):
        self.set_state(
            self.init_qpos +
            self.np_random.uniform(low=-.1, high=.1, size=self.model.nq),
            self.init_qvel +
            self.np_random.uniform(low=-.1, high=.1, size=self.model.nv)
        )
        return self._get_obs()
