# Testing
from rllab.sampler.utils_eva import rollout
from rllab.policies.random_uniform_policy import CustomisedRandomUniformPolicy


# define test function
# return a list, whose lenth is n_traj
def test_uniform_rand_adv(env, protag_policy, path_length, n_traj=5,
                          render=False, itr_epsilon=None, args=None):
    adv_policy = CustomisedRandomUniformPolicy(
        env_spec=env.spec,
        is_protagonist=False,
    )
    paths = []
    sum_rewards = 0.0
    for _ in range(n_traj):
        path = rollout(env, protag_policy, path_length,
                       adv_agent=adv_policy, animated=render,
                       test=True, itr_epsilon=itr_epsilon, args=args)
        sum_rewards += path['rewards'].sum()
        paths.append(path)
    avg_rewards = sum_rewards / n_traj
    return paths, avg_rewards


def test_learnt_adv(env, protag_policy, adv_policy, path_length, n_traj=5,
                    render=False, itr_epsilon=None, args=None):
    paths = []
    sum_rewards = 0.0
    for _ in range(n_traj):
        path = rollout(env, protag_policy, path_length,
                       adv_agent=adv_policy, animated=render,
                       test=True, itr_epsilon=itr_epsilon, args=args)
        sum_rewards += path['rewards'].sum()
        paths.append(path)
    avg_rewards = sum_rewards / n_traj
    return paths, avg_rewards
