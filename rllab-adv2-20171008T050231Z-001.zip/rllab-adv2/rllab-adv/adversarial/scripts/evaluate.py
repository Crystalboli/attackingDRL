from rllab.algos.trpo_anneal import TRPO
from rllab.baselines.linear_feature_baseline import LinearFeatureBaseline
from rllab.envs.gym_env import GymEnv
from rllab.envs.normalized_env import normalize
import rllab.misc.logger as logger
from rllab.sampler import parallel_sampler_eva
import numpy as np
from rllab.policies.gaussian_mlp_policy_anneal import GaussianMLPPolicy3
from test_eva import test_uniform_rand_adv, test_learnt_adv
import pickle
import argparse
import os
import math
import gym
import random
# from IPython import embed


BASELINE_DICT = {'HalfCheetah': '/HalfCheetah/env_HalfCheetahTorsoAdv-v1-Exp_3-Itr_300-BS_10000-Adv_1.0-stp_0.01-lam_0.97-ctrlNoise_0-actNoise_0-stateNoise_0-RARL_0-Baseline_1-epsilon_1e-12-epsGrad_1-epsParaBound_[0.0001, 0.01]-norm_2-process_1-anneal_2-66811.p',
                 'Swimmer': '/Swimmer/env_SwimmerAdv-v1-Exp_3-Itr_300-BS_10000-Adv_1.0-stp_0.01-lam_0.97-ctrlNoise_0-actNoise_0-stateNoise_0-RARL_0-Baseline_1-epsilon_1e-12-epsGrad_1-epsParaBound_[0.0001, 0.01]-norm_2-process_1-anneal_2-223732.p',
                 'Hopper': '/Hopper/env_HopperHeelAdv-v1-Exp_3-Itr_300-BS_10000-Adv_1.0-stp_0.01-lam_0.97-ctrlNoise_0-actNoise_0-stateNoise_0-RARL_0-Baseline_1-epsilon_1e-12-epsGrad_1-epsParaBound_[0.0001, 0.01]-norm_2-process_1-anneal_2-549629.p',
                 'Walker2D': '/Walker/env_Walker2dHeelAdv-v1-Exp_3-Itr_300-BS_10000-Adv_1.0-stp_0.01-lam_0.97-ctrlNoise_0-actNoise_0-stateNoise_0-RARL_0-Baseline_1-epsilon_1e-12-epsGrad_1-epsParaBound_[0.0001, 0.01]-norm_2-process_1-anneal_2-979083.p'}

# Pass arguments ##
parser = argparse.ArgumentParser()
parser.add_argument('--env', type=str, required=True,
                    choices=['HalfCheetah', 'Swimmer', 'Hopper', 'Walker2D'],
                    help='Name of adversarial environment')
parser.add_argument('--eps_range', nargs='+', type=float,
                    default=[0.0, 0.5, 0.01],
                    help='[start, stop, step]')
parser.add_argument('--n_traj', type=int, default=5,
                    help='number of trajectories in test for each epsilon')
parser.add_argument('--path_length', type=int, default=1000,
                    help='maximum episode length')
parser.add_argument('--folder', type=str, default=os.environ['HOME'],
                    help='folder to save result in')
parser.add_argument('--n_process', type=int, default=1,
                    help='Number of parallel threads for sampling environment')
parser.add_argument('--n_adv_itr', type=int, default=1,
                    help='Number of itrations for training adversarial')
parser.add_argument('--baseline', type=int, default=0,
                    help='whether to train baseline')
parser.add_argument('--RARL', type=int, default=0,
                    help='whether to train rarl')
parser.add_argument('--ctrl_noise', type=int, default=0,
                    help='whether adding noises on actions')
parser.add_argument('--act_noise', type=int, default=0,
                    help='whether adding noises on actions')
parser.add_argument('--state_noise', type=int, default=0,
                    help='whether adding noises on states')
parser.add_argument('--adv_test', type=int, default=0,
                    help='whether to do adversarial test')
parser.add_argument('--epsilon', type=float, default=0.01,
                    help='bound for constraining action sample')
parser.add_argument('--eps_grad', type=int, default=0,
                    help='whether applying gradual change to epsilon')
parser.add_argument('--eps_grad_paras', nargs='+', type=float,
                    default=[0.01446, 0.0001],
                    help='whether applying gradual change to epsilon')
parser.add_argument('--norm', type=int, default=1,
                    help='norm type: {1: l1, 2: l2, 3: inf}')
parser.add_argument('--seed', type=int, default=123456,
                    help='start random seed for settings')
parser.add_argument('--policy_index', type=int, default=1,
                    help='which trained policy you want to use')
parser.add_argument('--anneal_type', type=int, default=2,
                    help='1: log-linear; 2: exponential; 3: linear')


# Parsing Arguments ##
args = parser.parse_args()

# show args
print('Called with args:')
print(args)

# get args
env_key = args.env
eps_start, eps_stop, eps_step = args.eps_range
save_dir = args.folder
n_traj = int(args.n_traj)
n_process = args.n_process
set_seed = args.seed
path_length = args.path_length
adv_test = bool(args.adv_test)
policy_index = args.policy_index

# get the path for file containing trained policy
file_path = save_dir + '/robust-rl-notebook/20170910' + BASELINE_DICT[env_key]

# reload trained policy
res_D = pickle.load(open(file_path, 'rb'))
pro_policy = res_D['pro_policy'][policy_index - 1]
load_args = res_D['args']
env_name = load_args.env

# Initializing summaries for the tests
test_path = dict()

# Preparing file to save results in
save_prefix =\
    'Evaluate-env_{}-BS_{}-stp_{}-lam_{}-epsRange_{}-advTest_{}-adv_itr_{}-'\
    'ctrl_{}-state_{}-act_{}-norm_{}-process_{}-anneal_{}-policy_{}-{}'.format(
        env_name, load_args.batch_size, load_args.step_size,
        load_args.gae_lambda, args.eps_range, args.adv_test, args.n_adv_itr,
        args.ctrl_noise, args.state_noise, args.act_noise, args.norm,
        args.n_process, args.anneal_type, policy_index,
        random.randint(0, 1000000))
save_name = save_dir + '/' + save_prefix + '.p'


# Initializing the parallel sampler & set seed
parallel_sampler_eva.initialize(n_process)
parallel_sampler_eva.set_seed(set_seed + n_process)

# Environment definition
# The second argument in GymEnv defines
# the relative magnitude of adversary. For testing we set this to 1.0.
env = GymEnv(env_name, 1.0, args=args,
             seed=set_seed + n_process)

logger.log('\n\n\nEnv_name: {}\nbnames: {}\n'
           'adv_act_space_dim: {}\n'
           'pro_act_space_dim: {}\n\n\n'.format(
                    env_name, env.bnames,
                    env.adv_action_space.shape,
                    env.pro_action_space.shape))
env = normalize(env)

# Initialize adv_test
if adv_test is True:
    pro_baseline = LinearFeatureBaseline(env_spec=env.spec)

    adv_policy = GaussianMLPPolicy3(
        env_spec=env.spec,
        hidden_sizes=load_args.layer_size,
        is_protagonist=False,
        args=args
    )
    adv_baseline = LinearFeatureBaseline(env_spec=env.spec)

    adv_algo = TRPO(
        env=env,
        pro_policy=pro_policy,
        adv_policy=adv_policy,
        pro_baseline=pro_baseline,
        adv_baseline=adv_baseline,
        batch_size=load_args.batch_size,
        max_path_length=path_length,
        n_itr=args.n_adv_itr,
        discount=0.995,
        gae_lambda=load_args.gae_lambda,
        step_size=load_args.step_size,
        is_protagonist=False,
        scope='adversary_optim'
    )

# Looping over experiments to carry out
for itr_epsilon in np.arange(eps_start, eps_stop, eps_step):

    if adv_test is True:
        adv_algo.train(itr_epsilon)

        temp_list, avg_rewards = test_learnt_adv(
            env, pro_policy, adv_policy, path_length,
            n_traj=n_traj, render=False, itr_epsilon=itr_epsilon, args=args)
    else:
        temp_list, avg_rewards = test_uniform_rand_adv(
            env, pro_policy, path_length,
            n_traj=n_traj, render=False, itr_epsilon=itr_epsilon, args=args)

    logger.log('\n\n## Epsilon: {} | N_traj: {} ## | '
               'epsilon: {} | avg_rewards: {}\n\n'.format(
                itr_epsilon, n_traj, itr_epsilon, avg_rewards))

    test_path[itr_epsilon] = temp_list

    # Protagonist policy definition

if adv_test:
    pickle.dump({'args': args,
                 'load_args': load_args,
                 'eps_range': [eps_start, eps_stop, eps_step],
                 'pro_policy': pro_policy,
                 'adv_policy': adv_policy,
                 'rand_uniform_test': test_path},
                open(save_name, 'wb'))
else:
    pickle.dump({'args': args,
                 'load_args': load_args,
                 'eps_range': [eps_start, eps_stop, eps_step],
                 'pro_policy': pro_policy,
                 'rand_uniform_test': test_path},
                open(save_name, 'wb'))

logger.log('\n\n\n#### DONE ####\n\n\n')
