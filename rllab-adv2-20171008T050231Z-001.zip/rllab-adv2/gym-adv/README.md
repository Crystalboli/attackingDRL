> Under Development
# Gym environments with adversarial disturbance agents

This repository is complementary to the `rllab-adv` repository. This repo setts the environment of mujoco for tranining adversary.

## Getting Started

I strongly you create an **total new** environment for this repository.

### Install mujoco

This repository only supports **mujoco131**.

The environments are based on the MuJoCo environments wrapped by OpenAI Gym's environments ([info](https://gym.openai.com/envs#mujoco)). For more information on OpenAI Gym environments refer to the [Gym webpage](https://gym.openai.com/).

### Install mujoco-py

Since these environments use the OpenAI pyhton bindings for the MuJoCo environments, you'll need to install `mujoco-py` following [this](https://github.com/openai/mujoco-py). Please note you need to insatll version of **0.5.7** instead of the lastest one.

If you have problem of installing after following the normal steps OpenAI offered, I recommend you just use the following commands:

```
cd /your/path/to/mujoco-0.5.7
python setup.py install
```


### Install gym-adv

If you successfully pass the previous steps, you have only one thing to do. Use the following commands:

```
cd /your/path/to/gym-adv
pip install -e '.[all]' --no-cache
```


