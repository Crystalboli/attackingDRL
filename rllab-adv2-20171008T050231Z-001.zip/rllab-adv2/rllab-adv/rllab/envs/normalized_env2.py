import numpy as np

from rllab import spaces
from rllab.core.serializable import Serializable
from rllab.envs.proxy_env2 import ProxyEnv2
from rllab.spaces.box import Box
from rllab.misc.overrides import overrides
from rllab.envs.base2 import Step


class NormalizedEnv2(ProxyEnv2, Serializable):
    def __init__(
            self,
            env,
            scale_reward=1.,
            normalize_obs=False,
            normalize_reward=False,
            obs_alpha=0.001,
            reward_alpha=0.001,
    ):
        ProxyEnv2.__init__(self, env)
        Serializable.quick_init(self, locals())
        self._scale_reward = scale_reward
        self._normalize_obs = normalize_obs
        self._normalize_reward = normalize_reward
        self._obs_alpha = obs_alpha
        self._obs_mean = np.zeros(env.observation_space.flat_dim)
        self._obs_var = np.ones(env.observation_space.flat_dim)
        self._reward_alpha = reward_alpha
        self._reward_mean = 0.
        self._reward_var = 1.
        self._bnames = env.bnames

    def _update_obs_estimate(self, obs):
        flat_obs = self.wrapped_env.observation_space.flatten(obs)
        self._obs_mean =\
            (1 - self._obs_alpha) * self._obs_mean + self._obs_alpha * flat_obs
        self._obs_var =\
            (1 - self._obs_alpha) * self._obs_var +\
            self._obs_alpha * np.square(flat_obs - self._obs_mean)

    def _update_reward_estimate(self, reward):
        self._reward_mean =\
            (1 - self._reward_alpha) * self._reward_mean +\
            self._reward_alpha * reward
        self._reward_var =\
            (1 - self._reward_alpha) * self._reward_var +\
            self._reward_alpha * np.square(reward - self._reward_mean)

    def _apply_normalize_obs(self, obs):
        self._update_obs_estimate(obs)
        return (obs - self._obs_mean) / (np.sqrt(self._obs_var) + 1e-8)

    def _apply_normalize_reward(self, reward):
        self._update_reward_estimate(reward)
        return reward / (np.sqrt(self._reward_var) + 1e-8)

    def reset(self):
        ret = self._wrapped_env.reset()
        if self._normalize_obs:
            return self._apply_normalize_obs(ret)
        else:
            return ret

    def __getstate__(self):
        d = Serializable.__getstate__(self)
        d["_obs_mean"] = self._obs_mean
        d["_obs_var"] = self._obs_var
        return d

    def __setstate__(self, d):
        Serializable.__setstate__(self, d)
        self._obs_mean = d["_obs_mean"]
        self._obs_var = d["_obs_var"]

    @property
    @overrides
    def pro_action_space(self):
        # after this step, all actions are rescaled into [-1, 1]
        if isinstance(self._wrapped_env.pro_action_space, Box):
            ub = np.ones(self._wrapped_env.pro_action_space.shape)
            return spaces.Box(-1 * ub, ub)
        return self._wrapped_env.pro_action_space

    @property
    @overrides
    def adv_action_space_ctrl(self):
        # after this step, all actions are rescaled into [-1, 1]
        if isinstance(self._wrapped_env.adv_action_space_ctrl, Box):
            ub = np.ones(self._wrapped_env.adv_action_space_ctrl.shape)
            return spaces.Box(-1 * ub, ub)
        return self._wrapped_env.adv_action_space_ctrl

    @property
    @overrides
    def adv_action_space_obs(self):
        # after this step, all actions are rescaled into [-1, 1]
        if isinstance(self._wrapped_env.adv_action_space_obs, Box):
            ub = np.ones(self._wrapped_env.adv_action_space_obs.shape)
            return spaces.Box(-1 * ub, ub)
        return self._wrapped_env.adv_action_space_obs

    @overrides
    def step(self, action):
        pro_action = action.pro
        adv_action = action.adv
        scaled_action = action.__class__()
        if isinstance(self._wrapped_env.pro_action_space, Box):
            # rescale the action
            lb, ub = self._wrapped_env.pro_action_space.bounds
            scaled_pro_action = lb + (pro_action + 1.) * 0.5 * (ub - lb)
            scaled_pro_action = np.clip(scaled_pro_action, lb, ub)
        else:
            scaled_pro_action = pro_action

        # when add both ctrl and state noise,
        # only ctrl_noise will go into env.step()
        if isinstance(self._wrapped_env.adv_action_space_ctrl, Box):
            # rescale the action
            # in the situation where adding both state_noise and ctrl_noise,
            # since we only use ctrl_noise in step,
            # here only modify state_noise action
            lb, ub = self._wrapped_env.adv_action_space_ctrl.bounds
            scaled_adv_action = lb + (adv_action + 1.) * 0.5 * (ub - lb)
            scaled_adv_action = np.clip(scaled_adv_action, lb, ub)
        else:
            scaled_adv_action = adv_action

        scaled_action.pro = scaled_pro_action
        scaled_action.adv = scaled_adv_action

        wrapped_step = self._wrapped_env.step(scaled_action)
        next_obs, reward, done, info = wrapped_step
        if self._normalize_obs:
            next_obs = self._apply_normalize_obs(next_obs)
        if self._normalize_reward:
            reward = self._apply_normalize_reward(reward)
        return Step(next_obs, reward * self._scale_reward, done, **info)

    def __str__(self):
        return "Normalized: %s" % self._wrapped_env

    # def log_diagnostics(self, paths):
    #     print "Obs mean:", self._obs_mean
    #     print "Obs std:", np.sqrt(self._obs_var)
    #     print "Reward mean:", self._reward_mean
    #     print "Reward std:", np.sqrt(self._reward_var)


normalize2 = NormalizedEnv2
