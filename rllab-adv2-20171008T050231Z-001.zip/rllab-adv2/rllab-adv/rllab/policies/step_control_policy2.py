from rllab.core.parameterized import Parameterized
from rllab.core.serializable import Serializable
from rllab.distributions.delta import Delta
from rllab.policies.base import Policy
from rllab.misc.overrides import overrides
import random
import copy
import numpy as np


class StepControlPolicy2(Policy, Serializable):
    def __init__(
            self,
            env_spec,
            characteristic_length,
            step_size,
            is_random_mag=True,
            is_protagonist=True,
            args=None
    ):
        Serializable.quick_init(self, locals())
        if is_protagonist is True:
            cur_action_space = env_spec.pro_action_space
        else:
            if args is not None:
                if args.ctrl_noise and args.state_noise:
                    cur_action_space_ctrl = env_spec.adv_action_space_ctrl
                    cur_action_space_obs = env_spec.adv_action_space_obs
                    self.action_dim_ctrl = cur_action_space_ctrl.flat_dim
                    self.action_dim_obs = cur_action_space_obs.flat_dim
                    action_dim = self.action_dim_ctrl + self.action_dim_obs
                    self._action_space_ctrl = cur_action_space_ctrl
                    self._action_space_obs = cur_action_space_obs
                else:
                    raise ValueError
        # action_dim = cur_action_space.flat_dim
        # self._action_space = cur_action_space
        self._prob_step = 1.0 / characteristic_length
        self._in_step_looper_ctrl = 0
        self._in_step_looper_obs = 0
        self._step_size = step_size
        self._step_val_ctrl = None
        self._step_val_obs = None
        self._is_random_mag = is_random_mag
        self._cached_params = {}

    @overrides
    def get_action(self, observation, path_i, itr_epsilon=None):
        # ctrl noise
        if self._in_step_looper_ctrl == 0:
            if random.random() > self._prob_step:
                self.act_ctrl = self._action_space_ctrl.sample() * 0.0
            else:
                if self._is_random_mag is True:
                    self._step_val_ctrl = self._action_space_ctrl.sample()
                else:
                    self._step_val_ctrl = self._action_space_ctrl.bounds[1]
                self._in_step_looper_ctrl =\
                    (self._in_step_looper_ctrl + 1) % self._step_size
                self.act_ctrl = self._step_val_ctrl
        else:
            self._in_step_looper_ctrl =\
                (self._in_step_looper_ctrl + 1) % self._step_size

        # state noise
        if self._in_step_looper_obs == 0:
            if random.random() > self._prob_step:
                self.act_obs = self._action_space_obs.sample() * 0.0
            else:
                if self._is_random_mag is True:
                    self._step_val_obs = self._action_space_obs.sample()
                else:
                    # since observation space has no bound,
                    # we just use a large value here
                    self._step_val_obs = 999999999
                self._in_step_looper_obs =\
                    (self._in_step_looper_obs + 1) % self._step_size
                self.act_obs = self._step_val_obs
        else:
            self._in_step_looper_obs =\
                (self._in_step_looper_obs + 1) % self._step_size

        # ctrl noise must locate before state noise
        # action = copy.deepcopy(self.act_ctrl)
        action = np.append(self.act_ctrl, self.act_obs)
        return action, dict(ctrl_dim=self.action_dim_ctrl)

    def get_params_internal(self, **tags):
        return []

    def get_param_values(self, **tags):
        return []

    def get_actions(self, observations):
        raise NotImplementedError

    @property
    def vectorized(self):
        return True

    def reset(self, dones=None):
        pass

    @property
    def distribution(self):
        # Just a placeholder
        return Delta()
