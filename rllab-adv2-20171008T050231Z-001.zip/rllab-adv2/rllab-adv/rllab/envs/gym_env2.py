import gym
import gym.envs
import gym.spaces
from gym.monitoring import monitor
import os
import os.path as osp
from rllab.envs.base2 import Env2, Step
from rllab.core.serializable import Serializable
from rllab.spaces.box import Box
from rllab.spaces.discrete import Discrete
from rllab.spaces.product import Product
from rllab.misc import logger
import logging


def convert_gym_space(space):
    if isinstance(space, gym.spaces.Box):
        return Box(low=space.low, high=space.high)
    elif isinstance(space, gym.spaces.Discrete):
        return Discrete(n=space.n)
    elif isinstance(space, gym.spaces.Tuple):
        return Product([convert_gym_space(x) for x in space.spaces])
    else:
        raise NotImplementedError


class CappedCubicVideoSchedule(object):

    def __call__(self, count):
        return monitor.capped_cubic_video_schedule(count)


class FixedIntervalVideoSchedule(object):

    def __init__(self, interval):
        self.interval = interval

    def __call__(self, count):
        return count % self.interval == 0


class NoVideoSchedule(object):

    def __call__(self, count):
        return False


class GymEnv2(Env2, Serializable):

    def __init__(self, env_name, adv_fraction=1.0, record_video=True,
                 video_schedule=None, log_dir=None, record_log=True,
                 args=None, seed=None):
        if log_dir is None:
            if logger.get_snapshot_dir() is None:
                logger.log(
                    "Warning: skipping Gym environment monitoring since snapshot_dir not configured.")
            else:
                log_dir = os.path.join(logger.get_snapshot_dir(), "gym_log")
        Serializable.quick_init(self, locals())

        # make environment here
        env = gym.envs.make(env_name)
        if seed is not None:
            env.seed(seed)
        if args is not None:
            env.env_setup(args)
        # test
        # print("\n\n\nenv adv_act_space dimension is: {}\n\n\n".format(env.adv_action_space.shape))
        # adv_action_space defined in
        # /gym-adv-lerrel/gym/envs/adversarial/mujoco/env_name.py
        def_adv = env.adv_action_space.high[0]
        new_adv = def_adv * adv_fraction
        # Find this function in
        # /gym-adv/gym/envs/adversarial/mujoco/mujoco_env.py

        # only use this for RARL
        if args is not None:
            if args.RARL:
                env.update_adversary(new_adv)

        # ##
        self.env = env
        self.env_id = env.spec.id

        monitor.logger.setLevel(logging.WARNING)

        assert not (not record_log and record_video)

        if log_dir is None or record_log is False:
            self.monitoring = False
        else:
            if not record_video:
                video_schedule = NoVideoSchedule()
            else:
                if video_schedule is None:
                    video_schedule = CappedCubicVideoSchedule()
            # add 'force=True' if want overwrite dirs
            self.env.monitor.start(log_dir, video_schedule, force=True)
            self.monitoring = True

        self._observation_space = convert_gym_space(env.observation_space)
        self._pro_action_space = convert_gym_space(env.pro_action_space)
        self._adv_action_space_ctrl = convert_gym_space(env.adv_action_space_ctrl)
        self._adv_action_space_obs = convert_gym_space(env.adv_action_space_obs)
        self._horizon = env.spec.timestep_limit
        self._log_dir = log_dir
        self._bnames = env.bnames

    @property
    def observation_space(self):
        return self._observation_space

    # -------------------------------------
    # customize for protagonist and adversarial
    @property
    def pro_action_space(self):
        return self._pro_action_space

    @property
    def adv_action_space_ctrl(self):
        return self._adv_action_space_ctrl

    @property
    def adv_action_space_obs(self):
        return self._adv_action_space_obs

    @property
    def bnames(self):
        return self._bnames
    # -------------------------------------

    @property
    def horizon(self):
        return self._horizon

    def reset(self):
        if hasattr(self.env, 'monitor'):
            if hasattr(self.env.monitor, 'stats_recorder'):
                recorder = self.env.monitor.stats_recorder
                if recorder is not None:
                    recorder.done = True
        return self.env.reset()

    def step(self, action):
        next_obs, reward, done, info = self.env.step(action)
        return Step(next_obs, reward, done, **info)

    def render(self):
        self.env.render()

    def terminate(self):
        if self.monitoring:
            self.env.monitor.close()
            if self._log_dir is not None:
                print("""
    ***************************

    Training finished! You can upload results to OpenAI Gym by running the following command:

    python scripts/submit_gym.py %s

    ***************************
                """ % self._log_dir)
