from rllab.core.parameterized import Parameterized
from rllab.core.serializable import Serializable
from rllab.distributions.delta import Delta
from rllab.policies.base import Policy
from rllab.misc.overrides import overrides
from gym.spaces import Box
from IPython import embed
import copy
import numpy as np


class ConstantControlPolicy2(Policy, Serializable):

    def __init__(
            self,
            env_spec,
            is_protagonist=True,
            constant_val=0.0,
            args=None
    ):
        Serializable.quick_init(self, locals())
        if is_protagonist is True:
            cur_action_space = env_spec.pro_action_space
        else:
            if args is not None:
                if args.state_noise and args.ctrl_noise:
                    cur_action_space_ctrl = env_spec.adv_action_space_ctrl
                    cur_action_space_obs = env_spec.adv_action_space_obs
                    self.action_dim_ctrl = cur_action_space_ctrl.flat_dim
                    self.action_dim_obs = cur_action_space_obs.flat_dim
                    action_dim = self.action_dim_ctrl + self.action_dim_obs
                    self._action_space_ctrl = cur_action_space_ctrl
                    self._action_space_obs = cur_action_space_obs
                else:
                    raise ValueError
        # action_dim = cur_action_space.flat_dim
        # self._action_space = cur_action_space
        # assert isinstance(self._action_space, Box)
        self.constant_val = constant_val
        # super(UniformControlPolicy, self).__init__(env_spec=env_spec)
        self._cached_params = {}

    @overrides
    def get_action(self, observation, path_i, itr_epsilon=None):
        sample_action_ctrl =\
            self._action_space_ctrl.sample() * 0.0 + self.constant_val
        sample_action_obs =\
            self._action_space_obs.sample() * 0.0 + self.constant_val
        assert self._action_space_ctrl.contains(sample_action_ctrl)
        assert self._action_space_obs.contains(sample_action_obs)
        # ctrl noise must locate before state noise
        # pre_sample_action = copy.deepcopy(sample_action_ctrl)
        sample_action = np.append(sample_action_ctrl, sample_action_obs)
        return sample_action, dict(ctrl_dim=self.action_dim_ctrl)

    def get_params_internal(self, **tags):
        return []

    """
    def get_actions(self, observations):
        all_samples = []
        for obs in observations:
            sample_action = self._action_space.sample() * 0.0 + self.constant_val
            assert self._action_space.contains(sample_action)
            all_samples.append(sample_action)
        all_samples = np.array(all_samples)
        return all_samples, dict()
    """

    @property
    def vectorized(self):
        return True

    def reset(self, dones=None):
        pass

    @property
    def distribution(self):
        # Just a placeholder
        return Delta()
