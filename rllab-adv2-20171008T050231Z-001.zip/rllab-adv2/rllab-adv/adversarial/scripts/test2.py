# Testing
from rllab.sampler.utils2 import rollout2
from rllab.policies.constant_control_policy2 import ConstantControlPolicy2
from rllab.policies.random_uniform_control_policy2 import RandomUniformControlPolicy2
from rllab.policies.step_control_policy2 import StepControlPolicy2


def test_const_adv2(env, protag_policy,
                    path_length=100, n_traj=5, render=False, args=None):
    const_adv_policy = ConstantControlPolicy2(
        env_spec=env.spec,
        is_protagonist=False,
        constant_val=0.0,
        args=args
    )
    paths = []
    sum_rewards = 0.0
    for _ in range(n_traj):
        path = rollout2(env, protag_policy, path_length,
                        adv_agent=const_adv_policy, animated=render,
                        test=True, itr_epsilon=999999)
        sum_rewards += path['rewards'].sum()
        paths.append(path)
    avg_rewards = sum_rewards / n_traj
    return avg_rewards


def test_rand_adv2(env, protag_policy,
                   path_length=100, n_traj=5, render=False, args=None):
    adv_policy = RandomUniformControlPolicy2(
        env_spec=env.spec,
        is_protagonist=False,
        args=args,
    )
    paths = []
    sum_rewards = 0.0
    for _ in range(n_traj):
        path = rollout2(env, protag_policy, path_length,
                        adv_agent=adv_policy, animated=render,
                        test=True, itr_epsilon=999999)
        sum_rewards += path['rewards'].sum()
        paths.append(path)
    avg_rewards = sum_rewards / n_traj
    return avg_rewards


def test_rand_step_adv2(env, protag_policy,
                        path_length=100, n_traj=5, render=False, args=None):
    paths = []
    sum_rewards = 0.0
    characteristic_length = path_length / 5
    step_size = path_length / 10
    for _ in range(n_traj):
        adv_policy = StepControlPolicy2(
            env_spec=env.spec,
            characteristic_length=characteristic_length,
            step_size=step_size,
            is_random_mag=True,
            is_protagonist=False,
            args=args,
        )
        path = rollout2(env, protag_policy, path_length,
                        adv_agent=adv_policy, animated=render,
                        test=True, itr_epsilon=999999)
        sum_rewards += path['rewards'].sum()
        paths.append(path)
    avg_rewards = sum_rewards / n_traj
    return avg_rewards


def test_step_adv2(env, protag_policy,
                   path_length=100, n_traj=5, render=False, args=None):
    paths = []
    sum_rewards = 0.0
    characteristic_length = path_length / 5
    step_size = path_length / 10
    for _ in range(n_traj):
        adv_policy = StepControlPolicy2(
            env_spec=env.spec,
            characteristic_length=characteristic_length,
            step_size=step_size,
            is_random_mag=False,
            is_protagonist=False,
            args=args,
        )
        path = rollout2(env, protag_policy, path_length,
                        adv_agent=adv_policy, animated=render,
                        test=True, itr_epsilon=999999)
        sum_rewards += path['rewards'].sum()
        paths.append(path)
    avg_rewards = sum_rewards / n_traj
    return avg_rewards


def test_learnt_adv2(env, protag_policy, adv_policy,
                     path_length=100, n_traj=5, render=False,
                     itr_epsilon=None):
    paths = []
    sum_rewards = 0.0
    for _ in range(n_traj):
        path = rollout2(env, protag_policy, path_length,
                        adv_agent=adv_policy, animated=render,
                        test=True, itr_epsilon=itr_epsilon)
        sum_rewards += path['rewards'].sum()
        paths.append(path)
    avg_rewards = sum_rewards / n_traj
    return avg_rewards
