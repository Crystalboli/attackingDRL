from gym.envs.adversarial.mujoco.mujoco_env import MujocoEnv
# ^^^^^ so that user gets the correct error
# message if mujoco is not installed correctly
# from gym.envs.adversarial.mujoco.ant import AntEnv
# from gym.envs.adversarial.mujoco.ant_heel import AntHeelEnv
# from gym.envs.adversarial.mujoco.half_cheetah import HalfCheetahEnv
# from gym.envs.adversarial.mujoco.half_cheetah_heel import HalfCheetahHeelEnv
from gym.envs.adversarial.mujoco.half_cheetah_torso import HalfCheetahTorsoEnv
from gym.envs.adversarial.mujoco.half_cheetah_torso2 import HalfCheetahTorsoEnv2
# from gym.envs.adversarial.mujoco.hopper import HopperEnv
# from gym.envs.adversarial.mujoco.hopper_6 import Hopper6Env
from gym.envs.adversarial.mujoco.hopper_heel import HopperHeelEnv
from gym.envs.adversarial.mujoco.hopper_heel2 import HopperHeelEnv2
# from gym.envs.adversarial.mujoco.hopper_heel_6 import HopperHeel6Env
# from gym.envs.adversarial.mujoco.hopper_torso_6 import HopperTorso6Env
# from gym.envs.adversarial.mujoco.walker2d import Walker2dEnv
from gym.envs.adversarial.mujoco.walker2d_heel import Walker2dHeelEnv
from gym.envs.adversarial.mujoco.walker2d_heel2 import Walker2dHeelEnv2
# from gym.envs.adversarial.mujoco.walker2d_torso import Walker2dTorsoEnv
# from gym.envs.adversarial.mujoco.humanoid import HumanoidEnv
# from gym.envs.adversarial.mujoco.humanoid_heel import HumanoidHeelEnv
from gym.envs.adversarial.mujoco.inverted_pendulum import InvertedPendulumEnv
from gym.envs.adversarial.mujoco.inverted_pendulum2 import InvertedPendulumEnv2
# from gym.envs.adversarial.mujoco.inverted_double_pendulum import InvertedDoublePendulumEnv
# from gym.envs.adversarial.mujoco.reacher import ReacherEnv
from gym.envs.adversarial.mujoco.swimmer import SwimmerEnv
from gym.envs.adversarial.mujoco.swimmer2 import SwimmerEnv2
# from gym.envs.adversarial.mujoco.humanoidstandup import HumanoidStandupEnv
