import numpy as np
from numpy import linalg as LA
import math
from gym import utils, spaces
from gym.envs.adversarial.mujoco import mujoco_env


class Walker2dHeelEnv(mujoco_env.MujocoEnv, utils.EzPickle):

    def __init__(self):
        mujoco_env.MujocoEnv.__init__(self, "walker2d.xml", 4)
        utils.EzPickle.__init__(self)
        # Adversarial setup
        # Byte String name of body on which the adversary force will be applied
        self._adv_f_bname = [b'foot', b'foot_left']
        self.bnames = self.model.body_names
        # Index of the body on which the adversary force will be applied
        self._adv_bindex = [self.bnames.index(i) for i in self._adv_f_bname]
        """
        adv_max_force = 5.
        high_adv = np.ones(2 * len(self._adv_bindex)) * adv_max_force
        low_adv = -high_adv
        self.adv_action_space = spaces.Box(low_adv, high_adv)
        """
        self.adv_action_space = self.action_space
        self.pro_action_space = self.action_space

    def env_setup(self, args=None):
        if args is not None:
            self.sim_step = 0
            self.ctrl_noise = args.ctrl_noise
            self.act_noise = args.act_noise
            self.state_noise = args.state_noise
            self.RARL = args.RARL
            self.epsilon = args.epsilon
            self.eps_grad = args.eps_grad
            self.para_a, self.para_b = args.eps_grad_paras
            # norm type: {1: l1, 2: l2, 3: inf}
            self.norm = args.norm
            if self.RARL:
                adv_max_force = 5.
                high_adv = np.ones(2 * len(self._adv_bindex)) * adv_max_force
                low_adv = -high_adv
                self.adv_action_space = spaces.Box(low_adv, high_adv)
            elif self.act_noise:
                # The dimension of action space is [#body - 1, 3]
                # we just ignore the worldbody tag
                adv_max_force = 123456
                self.adv_act_space_dim = 3 * (len(self.bnames) - 1)
                high_adv = np.ones(self.adv_act_space_dim) * adv_max_force
                low_adv = - high_adv
                self.adv_action_space = spaces.Box(low_adv, high_adv)
            elif self.ctrl_noise:
                self.adv_act_space_dim = self.action_space.shape[0]
                self.adv_action_space = self.action_space
            elif self.state_noise:
                self.adv_act_space_dim = self.obs_dim
                self.adv_action_space = self.observation_space
            else:
                pass

    def _adv_to_xfrc(self, adv_act):
        # See reference here: http://www.mujoco.org/book/reference.html#mjData
        # It seems that the dimension of xfrc_applied is [#body, 6]
        # The 2nd dim is 6: force & torque
        new_xfrc = self.model.data.xfrc_applied * 0.0
        if self.act_noise:
            for i, bname in enumerate(self.bnames[1:]):
                new_xfrc[i + 1, :3] = adv_act[(i * 3):(i * 3 + 3)]
        else:
            for i, bindex in enumerate(self._adv_bindex):
                new_xfrc[bindex] = np.array(
                    [adv_act[i * 2], 0., adv_act[i * 2 + 1], 0., 0., 0.])
        self.model.data.xfrc_applied = new_xfrc

    def sample_action(self):
        if self.eps_grad:
            self.sim_step = self.sim_step + 1
            self.epsilon =\
                self.para_a * math.log(self.sim_step, math.exp(1)) + self.para_b

        class act(object):
            def __init__(self, pro=None, adv=None):
                self.pro = pro
                self.adv = adv

        if self.act_noise:
            pre_sample_adv_act = np.random.normal(size=self.adv_act_space_dim)
            if self.norm == 1:
                sample_norm = LA.norm(pre_sample_adv_act, 1)
                sample_adv_act =\
                    self.epsilon * pre_sample_adv_act / (sample_norm + 1e-8)
            elif self.norm == 2:
                sample_norm = LA.norm(pre_sample_adv_act, 2)
                sample_adv_act =\
                    np.sqrt(self.epsilon) * pre_sample_adv_act / (sample_norm + 1e-8)
            elif self.norm == 3:
                sample_norm = LA.norm(pre_sample_adv_act, np.inf)
                if np.abs(sample_norm) > self.epsilon:
                    pre_sample_adv_act[np.where(np.abs(pre_sample_adv_act) == sample_norm)]\
                        = self.epsilon
                sample_adv_act = pre_sample_adv_act
            else:
                raise ValueError
        else:
            sample_adv_act = self.adv_action_space.sample()

        sa = act(self.pro_action_space.sample(), sample_adv_act)
        return sa

    def _step(self, action):
        if hasattr(action, '__dict__'):
            if self.act_noise or self.RARL:
                self._adv_to_xfrc(action.adv)
                a = action.pro
            elif self.ctrl_noise:
                a = action.pro + action.adv
            else:
                a = action.pro
        else:
            a = action

        posbefore = self.model.data.qpos[0, 0]
        self.do_simulation(a, self.frame_skip)
        posafter, height, ang = self.model.data.qpos[0:3, 0]
        alive_bonus = 1.0
        reward = ((posafter - posbefore) / self.dt)
        reward += alive_bonus
        reward -= 1e-3 * np.square(a).sum()
        done = not (height > 0.8 and height < 2.0 and ang > -1.0 and ang < 1.0)
        ob = self._get_obs()
        return ob, reward, done, {}

    def _get_obs(self):
        qpos = self.model.data.qpos
        qvel = self.model.data.qvel
        return np.concatenate([qpos[1:], np.clip(qvel, -10, 10)]).ravel()

    def reset_model(self):
        self.set_state(
            self.init_qpos +
            self.np_random.uniform(low=-.005, high=.005, size=self.model.nq),
            self.init_qvel +
            self.np_random.uniform(low=-.005, high=.005, size=self.model.nv)
        )
        return self._get_obs()

    def reset_model_zero(self):
        qpos = self.init_qpos
        qvel = self.init_qvel
        self.set_state(qpos, qvel)
        return self._get_obs()

    def viewer_setup(self):
        self.viewer.cam.trackbodyid = 2
        self.viewer.cam.distance = self.model.stat.extent * 0.5
        self.viewer.cam.lookat[2] += .8
        self.viewer.cam.elevation = -20
