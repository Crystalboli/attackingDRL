from rllab.algos.trpo import TRPO
from rllab.baselines.linear_feature_baseline import LinearFeatureBaseline
from rllab.envs.gym_env import GymEnv
from rllab.envs.normalized_env import normalize
from rllab.policies.gaussian_mlp_policy import GaussianMLPPolicy
from rllab.policies.random_uniform_control_policy import RandomUniformControlPolicy
from rllab.policies.constant_control_policy import ConstantControlPolicy
from IPython import embed
import matplotlib.pyplot as plt
import rllab.misc.logger as logger
import numpy as np
from test import test_const_adv, test_rand_adv, test_learnt_adv, test_rand_step_adv, test_step_adv
import pickle
import argparse
import os
import gym
import random
from rllab.sampler import parallel_sampler
from theano.tensor.shared_randomstreams import RandomStreams


# Pass arguments
parser = argparse.ArgumentParser()
parser.add_argument('--env', type=str, required=True,
                    help='Name of adversarial environment')
parser.add_argument('--adv_name', type=str, default='no_adv',
                    help='DOESNT MATTER FOR THIS BASELINE')
parser.add_argument('--path_length', type=int, default=1000,
                    help='maximum episode length')
parser.add_argument('--layer_size', nargs='+', type=int,
                    default=[64, 64], help='layer definition')
parser.add_argument('--if_render', type=int, default=0,
                    help='Should we animate at all?')
parser.add_argument('--after_render', type=int, default=100,
                    help='After how many to animate')
parser.add_argument('--n_exps', type=int, default=3, help='')
parser.add_argument('--n_itr', type=int, default=100, help='')
parser.add_argument('--n_pro_itr', type=int, default=1, help='')
parser.add_argument('--n_adv_itr', type=int, default=1, help='')
parser.add_argument('--batch_size', type=int, default=10000, help='')
parser.add_argument('--save_every', type=int, default=100, help='')
parser.add_argument('--n_process', type=int, default=1,
                    help='Number of threads for sampling environment')
parser.add_argument('--adv_fraction', type=float, default=1.0,
                    help='fraction of maximum adversarial force to be applied')
parser.add_argument('--step_size', type=float, default=0.01,
                    help='step size for learner')
parser.add_argument('--gae_lambda', type=float,
                    default=0.97, help='gae_lambda for learner')
parser.add_argument('--folder', type=str, default=os.environ['HOME'],
                    help='folder to save result in')
parser.add_argument('--baseline', type=int, default=0,
                    help='whether to train baseline')
parser.add_argument('--RARL', type=int, default=0,
                    help='whether to train rarl')
parser.add_argument('--ctrl_noise', type=int, default=0,
                    help='whether adding noises on actions')
parser.add_argument('--act_noise', type=int, default=0,
                    help='whether adding noises on actions')
parser.add_argument('--state_noise', type=int, default=0,
                    help='whether adding noises on states')
parser.add_argument('--epsilon', type=float, default=0.01,
                    help='bound for constraining action sample')
parser.add_argument('--eps_grad', type=int, default=0,
                    help='whether applying gradual change to epsilon')
parser.add_argument('--eps_grad_paras', nargs='+', type=float,
                    default=[0.01446, 0.0001],
                    help='whether applying gradual change to epsilon')
parser.add_argument('--norm', type=int, default=1,
                    help='norm type: {1: l1, 2: l2, 3: inf}')
parser.add_argument('--seed', type=int, default=123456,
                    help='start random seed for settings')

args = parser.parse_args()

# show args
print('Called with args:')
print(args)

# Number of experiments to run ##
env_name = args.env
adv_name = args.adv_name
path_length = args.path_length
layer_size = tuple(args.layer_size)
ifRender = bool(args.if_render)
afterRender = args.after_render
n_exps = args.n_exps
n_itr = args.n_itr
n_pro_itr = args.n_pro_itr
n_adv_itr = args.n_adv_itr
batch_size = args.batch_size
save_every = args.save_every
n_process = args.n_process
adv_fraction = 1.0
step_size = args.step_size
gae_lambda = args.gae_lambda
save_dir = args.folder
baseline_flag = args.baseline
RARL = args.RARL
ctrl_noise = args.ctrl_noise
act_noise = args.act_noise
state_noise = args.state_noise
epsilon = args.epsilon
eps_grad = args.eps_grad
eps_grad_paras = args.eps_grad_paras
norm = args.norm
set_seed = args.seed

const_test_rew_summary = []
rand_test_rew_summary = []
step_test_rew_summary = []
rand_step_test_rew_summary = []
adv_test_rew_summary = []
save_prefix =\
    'BASELINE-env_{}-{}-Exp_{}-Itr_{}-BS_{}-'\
    'Adv_{}-stp_{}-lam_{}-{}'.format(
        env_name, adv_name, n_exps, n_itr, batch_size,
        adv_fraction, step_size, gae_lambda, random.randint(0, 1000000))
# save_dir = os.environ['HOME'] + '/results/baselines'
fig_dir = 'figs'
save_name = save_dir + '/' + save_prefix + '.p'
fig_name = fig_dir + '/' + save_prefix + '.png'

for ne in range(n_exps):
    # Optimizer for the Protagonist
    parallel_sampler.initialize(n_process)
    parallel_sampler.set_seed(set_seed + ne * n_process * n_itr)

    # Environment definition
    env = GymEnv(env_name, adv_fraction, args=args,
                 seed=set_seed + ne * n_process * n_itr)

    logger.log('\n\n\nEnv_name: {}\nbnames: {}\n'
               'adv_act_space_dim: {}\n'
               'pro_act_space_dim: {}\n\n\n'.format(
                env_name, env.bnames, env.adv_action_space.shape,
                env.pro_action_space.shape))
    env = normalize(env)

    # Protagonist policy definition
    pro_policy = GaussianMLPPolicy(
        env_spec=env.spec,
        hidden_sizes=layer_size,
        is_protagonist=True,
        args=args
    )
    pro_baseline = LinearFeatureBaseline(env_spec=env.spec)

    # Zero Adversary for the protagonist training
    zero_adv_policy = ConstantControlPolicy(
        env_spec=env.spec,
        is_protagonist=False,
        constant_val=0.0
    )

    if adv_name == 'no_adv':
        pro_algo = TRPO(
            env=env,
            pro_policy=pro_policy,
            adv_policy=zero_adv_policy,
            pro_baseline=pro_baseline,
            adv_baseline=pro_baseline,
            batch_size=batch_size,
            max_path_length=path_length,
            n_itr=n_pro_itr,
            discount=0.995,
            gae_lambda=gae_lambda,
            step_size=step_size,
            is_protagonist=True
        )

    # Joint optimization
    if ifRender is True:
        test_const_adv(env, pro_policy, path_length=path_length,
                       n_traj=1, render=True)
    pro_rews = []
    adv_rews = []
    all_rews = []
    const_testing_rews = []
    const_testing_rews.append(test_const_adv(
        env, pro_policy, path_length=path_length))
    rand_testing_rews = []
    rand_testing_rews.append(test_rand_adv(
        env, pro_policy, path_length=path_length))
    step_testing_rews = []
    step_testing_rews.append(test_step_adv(
        env, pro_policy, path_length=path_length))
    rand_step_testing_rews = []
    rand_step_testing_rews.append(test_rand_step_adv(
        env, pro_policy, path_length=path_length))
    adv_testing_rews = []
    adv_testing_rews.append(test_rand_adv(
        env, pro_policy, path_length=path_length))
    # embed()
    for ni in range(n_itr):
        logger.log('\n\n\n#### Exp No: #{} | Global Itr: #{} | '
                   'n_pro_itr: #{} ####\n\n\n'.format(ne, ni, args.n_pro_itr))
        pro_algo.train()
        pro_rews += pro_algo.rews
        all_rews += pro_algo.rews
        logger.log('Protag Reward: {}'.format(np.array(pro_algo.rews).mean()))
        const_testing_rews.append(test_const_adv(
            env, pro_policy, path_length=path_length))
        rand_testing_rews.append(test_rand_adv(
            env, pro_policy, path_length=path_length))
        step_testing_rews.append(test_step_adv(
            env, pro_policy, path_length=path_length))
        rand_step_testing_rews.append(test_rand_step_adv(
            env, pro_policy, path_length=path_length))
        adv_testing_rews.append(test_rand_adv(
            env, pro_policy, path_length=path_length))
        if (ni + 1) % save_every == 0:
            # SAVING INFO
            pickle.dump({'args': args,
                         'pro_policy': pro_policy,
                         'zero_test': const_test_rew_summary,
                         'rand_test': rand_test_rew_summary,
                         'step_test': step_test_rew_summary,
                         'rand_step_test': rand_step_test_rew_summary,
                         'iter_save': ni,
                         'exp_save': ne,
                         'adv_test': adv_test_rew_summary},
                        open(save_name + '.temp', 'wb'))

    # Shutting down the optimizer
    pro_algo.shutdown_worker()
    const_test_rew_summary.append(const_testing_rews)
    rand_test_rew_summary.append(rand_testing_rews)
    step_test_rew_summary.append(step_testing_rews)
    rand_step_test_rew_summary.append(rand_step_testing_rews)
    adv_test_rew_summary.append(adv_testing_rews)

# SAVING INFO
pickle.dump({'args': args,
             'pro_policy': pro_policy,
             'zero_test': const_test_rew_summary,
             'rand_test': rand_test_rew_summary,
             'step_test': step_test_rew_summary,
             'rand_step_test': rand_step_test_rew_summary,
             'adv_test': adv_test_rew_summary}, open(save_name, 'wb'))

logger.log('\n\n\n#### DONE ####\n\n\n')
