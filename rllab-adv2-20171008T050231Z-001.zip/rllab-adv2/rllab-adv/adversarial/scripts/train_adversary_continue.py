from rllab.algos.trpo import TRPO
from rllab.baselines.linear_feature_baseline import LinearFeatureBaseline
from rllab.envs.gym_env import GymEnv
from rllab.envs.normalized_env import normalize
from rllab.policies.gaussian_mlp_policy import GaussianMLPPolicy
from rllab.policies.constant_control_policy import ConstantControlPolicy
import rllab.misc.logger as logger
from rllab.sampler import parallel_sampler
import matplotlib.pyplot as plt
import numpy as np
from test import test_const_adv, test_rand_adv, test_learnt_adv,\
    test_rand_step_adv, test_step_adv
import pickle
import argparse
import os
import gym
import random
from rllab.misc.console import colorize
# from IPython import embed


# Pass arguments ##
parser = argparse.ArgumentParser()
parser.add_argument('--folder', type=str, default=os.environ['HOME'],
                    help='folder to save result in')
parser.add_argument('--file', type=str, default=None,
                    help='file to load policy')


# Parsing Arguments ##
args = parser.parse_args()

# show args
print('Called with args:')
print(args)

save_dir = args.folder
f_path = args.file

# load tranined policy
res_D = pickle.load(open(f_path, 'rb'))
load_args = res_D['args']

if not load_args.baseline:
    adv_policy = res_D['adv_policy']
pro_policy = res_D['pro_policy']
const_test_rew_summary = res_D['zero_test']
rand_test_rew_summary = res_D['rand_test']
step_test_rew_summary = res_D['step_test']
rand_step_test_rew_summary = res_D['rand_step_test']
adv_test_rew_summary = res_D['adv_test']
iter_save = res_D['iter_save']
exp_save = res_D['exp_save']

env_name = load_args.env
adv_name = load_args.adv_name
path_length = load_args.path_length
layer_size = tuple(load_args.layer_size)
ifRender = bool(load_args.if_render)
afterRender = load_args.after_render
n_exps = load_args.n_exps
n_itr = load_args.n_itr
n_pro_itr = load_args.n_pro_itr
n_adv_itr = load_args.n_adv_itr
batch_size = load_args.batch_size
save_every = load_args.save_every
n_process = load_args.n_process
adv_fraction = load_args.adv_fraction
step_size = load_args.step_size
gae_lambda = load_args.gae_lambda
# save_dir = load_args.folder
baseline_flag = load_args.baseline
RARL = load_args.RARL
ctrl_noise = load_args.ctrl_noise
act_noise = load_args.act_noise
state_noise = load_args.state_noise
epsilon = load_args.epsilon
eps_grad = load_args.eps_grad
eps_grad_paras = load_args.eps_grad_paras
norm = load_args.norm
set_seed = load_args.seed


# Preparing file to save results in
save_prefix =\
    'Continue-env_{}-Exp_{}-Itr_{}-BS_{}-Adv_{}-stp_{}-lam_{}-'\
    'ctrlNoise_{}-actNoise_{}-stateNoise_{}-RARL_{}-Baseline_{}-epsilon_{}-'\
    'epsGrad_{}-epsPara_{}-norm_{}-process_{}-{}'.format(
        env_name, n_exps, n_itr, batch_size, adv_fraction, step_size,
        gae_lambda, ctrl_noise, act_noise, state_noise, RARL, baseline_flag,
        epsilon, eps_grad, eps_grad_paras, norm, n_process,
        random.randint(0, 1000000))
save_name = save_dir + '/' + save_prefix + '.p'

# Looping over experiments to carry out
for ne in range(exp_save, n_exps):
    # Initializing the parallel sampler & set seed
    parallel_sampler.initialize(n_process)
    parallel_sampler.set_seed(set_seed + ne * n_process * n_itr)

    # Environment definition
    # The second argument in GymEnv defines
    # the relative magnitude of adversary. For testing we set this to 1.0.
    env = GymEnv(env_name, adv_fraction, args=load_args,
                 seed=set_seed + ne * n_process * n_itr)

    # print out parameters
    logger.log('\n\n\nEnv_name: {}\nbnames: {}\n'
               'adv_act_space_dim: {}\n'
               'pro_act_space_dim: {}\n\n\n'.format(
                    env_name, env.bnames,
                    env.adv_action_space.shape,
                    env.pro_action_space.shape))
    env = normalize(env)

    # Protagonist policy definition
    pro_policy = GaussianMLPPolicy(
        env_spec=env.spec,
        hidden_sizes=layer_size,
        is_protagonist=True,
        args=load_args
    )
    pro_baseline = LinearFeatureBaseline(env_spec=env.spec)

    # Zero Adversary for the protagonist training
    # ConstantControlPolicy is a algorithm written by author
    zero_adv_policy = ConstantControlPolicy(
        env_spec=env.spec,
        is_protagonist=False,
        constant_val=0.0
    )

    if not baseline_flag:
        env_orig = GymEnv(env_name, 1.0, args=load_args)
        env_orig = normalize(env_orig)
        # Adversary policy definition
        adv_policy = GaussianMLPPolicy(
            env_spec=env.spec,
            hidden_sizes=layer_size,
            is_protagonist=False,
            args=load_args
        )
        adv_baseline = LinearFeatureBaseline(env_spec=env.spec)

    # Initializing the parallel sampler & set seed
    # parallel_sampler.initialize(n_process)
    # parallel_sampler.set_seed(set_seed + ne * n_process)

    # Optimizer for the Protagonist
    # Changes are made in NPO
    if baseline_flag:
        pro_algo = TRPO(
            env=env,
            pro_policy=pro_policy,
            adv_policy=zero_adv_policy,
            pro_baseline=pro_baseline,
            adv_baseline=pro_baseline,
            batch_size=batch_size,
            max_path_length=path_length,
            n_itr=n_pro_itr,
            discount=0.995,
            gae_lambda=gae_lambda,
            step_size=step_size,
            is_protagonist=True
        )
    else:
        pro_algo = TRPO(
            env=env,
            pro_policy=pro_policy,
            adv_policy=adv_policy,
            pro_baseline=pro_baseline,
            adv_baseline=adv_baseline,
            batch_size=batch_size,
            max_path_length=path_length,
            n_itr=n_pro_itr,
            discount=0.995,
            gae_lambda=gae_lambda,
            step_size=step_size,
            is_protagonist=True
        )

    # Optimizer for the Adversary
    if not baseline_flag:
        adv_algo = TRPO(
            env=env,
            pro_policy=pro_policy,
            adv_policy=adv_policy,
            pro_baseline=pro_baseline,
            adv_baseline=adv_baseline,
            batch_size=batch_size,
            max_path_length=path_length,
            n_itr=n_adv_itr,
            discount=0.995,
            gae_lambda=gae_lambda,
            step_size=step_size,
            is_protagonist=False,
            scope='adversary_optim'
        )

    # Setting up summaries for testing for a specific training instance
    pro_rews = []
    adv_rews = []
    all_rews = []
    if baseline_flag:
        env_orig = env
    const_testing_rews = []
    const_testing_rews.append(test_const_adv(
        env_orig, pro_policy, path_length=path_length))
    rand_testing_rews = []
    rand_testing_rews.append(test_rand_adv(
        env_orig, pro_policy, path_length=path_length))
    step_testing_rews = []
    step_testing_rews.append(test_step_adv(
        env_orig, pro_policy, path_length=path_length))
    rand_step_testing_rews = []
    rand_step_testing_rews.append(test_rand_step_adv(
        env_orig, pro_policy, path_length=path_length))
    adv_testing_rews = []
    if baseline_flag:
        adv_testing_rews.append(test_rand_adv(
            env, pro_policy, path_length=path_length))
    else:
        adv_testing_rews.append(test_learnt_adv(
            env, pro_policy, adv_policy, path_length=path_length))

    # Beginning alternating optimization
    for ni in range(n_itr):
        logger.log('\n\n\n#### Exp No: #{} | Global Itr: #{} | '
                   'n_pro_itr: #{} ####\n\n\n'.format(ne, ni, load_args.n_pro_itr))
        # Train protagonist
        pro_algo.train()
        pro_rews += pro_algo.rews
        all_rews += pro_algo.rews
        logger.log('Protag Reward: {}'.format(np.array(pro_algo.rews).mean()))
        # Do not train Adversary ONLY when there is state_noise
        if load_args.baseline:
            logger.log('Only baseline, do not train adversary')
        else:
            adv_algo.train()
            adv_rews += adv_algo.rews
            all_rews += adv_algo.rews
            logger.log('Advers Reward: {}'.format(np.array(adv_algo.rews).mean()))
        # Test the learnt policies
        const_testing_rews.append(
            test_const_adv(env, pro_policy, path_length=path_length))
        rand_testing_rews.append(
            test_rand_adv(env, pro_policy, path_length=path_length))
        step_testing_rews.append(
            test_step_adv(env, pro_policy, path_length=path_length))
        rand_step_testing_rews.append(
            test_rand_step_adv(env, pro_policy, path_length=path_length))
        if baseline_flag:
            adv_testing_rews.append(test_rand_adv(
                env, pro_policy, path_length=path_length))
        else:
            adv_testing_rews.append(
                test_learnt_adv(env, pro_policy, adv_policy,
                                path_length=path_length))

        if ni % afterRender == 0 and ifRender is True:
            test_const_adv(env, pro_policy,
                           path_length=path_length, n_traj=1, render=True)

        if (ni + 1) % save_every == 0:
            if baseline_flag:
                pickle.dump({'args': load_args,
                             'pro_policy': pro_policy,
                             'zero_test': const_test_rew_summary,
                             'rand_test': rand_test_rew_summary,
                             'step_test': step_test_rew_summary,
                             'rand_step_test': rand_step_test_rew_summary,
                             'iter_save': ni,
                             'exp_save': ne,
                             'adv_test': adv_test_rew_summary},
                            open(save_name + '.temp', 'wb'))
            else:
                # SAVING CHECKPOINT INFO
                pickle.dump({'args': load_args,
                             'pro_policy': pro_policy,
                             'adv_policy': adv_policy,
                             'zero_test': const_test_rew_summary,
                             'rand_test': rand_test_rew_summary,
                             'step_test': step_test_rew_summary,
                             'rand_step_test': rand_step_test_rew_summary,
                             'iter_save': ni,
                             'exp_save': ne,
                             'adv_test': adv_test_rew_summary},
                            open(save_name + '.temp', 'wb'))

    # Shutting down the optimizer
    pro_algo.shutdown_worker()
    if not baseline_flag:
        adv_algo.shutdown_worker()

    # Updating the test summaries over all training instances
    const_test_rew_summary.append(const_testing_rews)
    rand_test_rew_summary.append(rand_testing_rews)
    step_test_rew_summary.append(step_testing_rews)
    rand_step_test_rew_summary.append(rand_step_testing_rews)
    adv_test_rew_summary.append(adv_testing_rews)

# SAVING INFO
if baseline_flag:
    pickle.dump({'args': load_args,
                 'pro_policy': pro_policy,
                 'zero_test': const_test_rew_summary,
                 'rand_test': rand_test_rew_summary,
                 'step_test': step_test_rew_summary,
                 'rand_step_test': rand_step_test_rew_summary,
                 'iter_save': ni,
                 'exp_save': ne,
                 'adv_test': adv_test_rew_summary},
                open(save_name, 'wb'))
else:
    # SAVING CHECKPOINT INFO
    pickle.dump({'args': load_args,
                 'pro_policy': pro_policy,
                 'adv_policy': adv_policy,
                 'zero_test': const_test_rew_summary,
                 'rand_test': rand_test_rew_summary,
                 'step_test': step_test_rew_summary,
                 'rand_step_test': rand_step_test_rew_summary,
                 'iter_save': ni,
                 'exp_save': ne,
                 'adv_test': adv_test_rew_summary},
                open(save_name, 'wb'))

logger.log('\n\n\n#### DONE ####\n\n\n')
