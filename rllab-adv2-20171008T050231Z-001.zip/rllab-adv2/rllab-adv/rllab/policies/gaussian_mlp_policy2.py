# -----------------------------------------------------
# This policy is for adversary agent to apply noises on
# protagonist's action and env's observation.
# -----------------------------------------------------

import lasagne
import lasagne.layers as L
import lasagne.nonlinearities as NL
import numpy as np
from numpy import linalg as LA
import math
import copy

from rllab.core.lasagne_layers import ParamLayer
from rllab.core.lasagne_powered import LasagnePowered
from rllab.core.network import MLP
from rllab.spaces import Box

from rllab.core.serializable import Serializable
from rllab.policies.base import StochasticPolicy
from rllab.misc.overrides import overrides
from rllab.misc import logger
from rllab.misc import ext
from rllab.distributions.diagonal_gaussian import DiagonalGaussian
import theano.tensor as TT


class GaussianMLPPolicy2(StochasticPolicy, LasagnePowered, Serializable):
    def __init__(
            self,
            env_spec,
            hidden_sizes=(32, 32),
            learn_std=True,
            init_std=1.0,
            adaptive_std=False,
            std_share_network=False,
            std_hidden_sizes=(32, 32),
            min_std=1e-6,
            std_hidden_nonlinearity=NL.tanh,
            hidden_nonlinearity=NL.tanh,
            output_nonlinearity=None,
            mean_network=None,
            std_network=None,
            dist_cls=DiagonalGaussian,
            is_protagonist=True,
            args=None
    ):
        """
        :param env_spec:
        :param hidden_sizes: list of sizes for the fully-connected hidden layers
        :param learn_std: Is std trainable
        :param init_std: Initial std
        :param adaptive_std:
        :param std_share_network:
        :param std_hidden_sizes: list of sizes for the fully-connected layers for std
        :param min_std: whether to make sure that the std is at least some threshold value, to avoid numerical issues
        :param std_hidden_nonlinearity:
        :param hidden_nonlinearity: nonlinearity used for each hidden layer
        :param output_nonlinearity: nonlinearity for the output layer
        :param mean_network: custom network for the output mean
        :param std_network: custom network for the output log std
        :return:
        """
        Serializable.quick_init(self, locals())

        # add some attributes for constraining sample actions
        self.is_protagonist = is_protagonist
        self.bnames = env_spec.bnames
        sim_step = 0
        # test
        # print('\n\n\nenv_spec: {}\n\n\n'.format(dir(env_spec)))
        if args is not None:
            self.ctrl_noise = args.ctrl_noise
            self.act_noise = args.act_noise
            self.state_noise = args.state_noise
            self.baseline_flag = args.baseline
            self.RARL = args.RARL
            self.epsilon = args.epsilon
            self.eps_grad = args.eps_grad
            self.para_a, self.para_b = args.eps_grad_paras
            self.norm = args.norm
            self.anneal_type = args.anneal_type
            # test
            """
            print('\n\n\nThis is in Gaussian MLP Policy, bnames: {};'
                  'state noise: {}; ctrl noise: {}; epsilon: {}; norm: {}\n\n\n'.format(
                    self.bnames, self.state_noise, self.ctrl_noise, self.epsilon, self.norm))
            """

        if self.is_protagonist is True:
            cur_action_space = env_spec.pro_action_space
            assert isinstance(cur_action_space, Box)
        else:
            if self.ctrl_noise and self.state_noise:
                cur_action_space_ctrl = env_spec.adv_action_space_ctrl
                cur_action_space_obs = env_spec.adv_action_space_obs
                assert isinstance(cur_action_space_ctrl, Box)
                assert isinstance(cur_action_space_obs, Box)
            else:
                cur_action_space = env_spec.adv_action_space
                assert isinstance(cur_action_space, Box)

        obs_dim = env_spec.observation_space.flat_dim
        if self.is_protagonist is not True:
            if self.ctrl_noise and self.state_noise:
                self.action_dim_ctrl = cur_action_space_ctrl.flat_dim
                self.action_dim_obs = cur_action_space_obs.flat_dim
                action_dim = self.action_dim_ctrl + self.action_dim_obs
            else:
                action_dim = cur_action_space.flat_dim
        else:
            action_dim = cur_action_space.flat_dim

        self.action_dim = action_dim
        # print("\n\n\nIn MLP, action_dim is {}\n\n\n".format(self.action_dim))

        # create network
        if mean_network is None:
            mean_network = MLP(
                input_shape=(obs_dim,),
                output_dim=action_dim,
                hidden_sizes=hidden_sizes,
                hidden_nonlinearity=hidden_nonlinearity,
                output_nonlinearity=output_nonlinearity,
            )
        self._mean_network = mean_network

        l_mean = mean_network.output_layer
        obs_var = mean_network.input_layer.input_var

        if std_network is not None:
            l_log_std = std_network.output_layer
        else:
            if adaptive_std:
                std_network = MLP(
                    input_shape=(obs_dim,),
                    input_layer=mean_network.input_layer,
                    output_dim=action_dim,
                    hidden_sizes=std_hidden_sizes,
                    hidden_nonlinearity=std_hidden_nonlinearity,
                    output_nonlinearity=None,
                )
                l_log_std = std_network.output_layer
            else:
                l_log_std = ParamLayer(
                    mean_network.input_layer,
                    num_units=action_dim,
                    param=lasagne.init.Constant(np.log(init_std)),
                    name="output_log_std",
                    trainable=learn_std,
                )

        self.min_std = min_std

        # here the dimension of mean_var & log_std_var is the same as
        # the customized adversary action space
        mean_var, log_std_var = L.get_output([l_mean, l_log_std])

        if self.min_std is not None:
            log_std_var = TT.maximum(log_std_var, np.log(min_std))

        self._mean_var, self._log_std_var = mean_var, log_std_var

        self._l_mean = l_mean
        self._l_log_std = l_log_std

        self._dist = dist_cls(action_dim)

        LasagnePowered.__init__(self, [l_mean, l_log_std])
        super(GaussianMLPPolicy2, self).__init__(env_spec)

        self._f_dist = ext.compile_function(
            inputs=[obs_var],
            outputs=[mean_var, log_std_var],
        )

    def dist_info_sym(self, obs_var, state_info_vars=None):
        mean_var, log_std_var =\
            L.get_output([self._l_mean, self._l_log_std], obs_var)
        if self.min_std is not None:
            log_std_var = TT.maximum(log_std_var, np.log(self.min_std))
        return dict(mean=mean_var, log_std=log_std_var)

    @overrides
    def get_action(self, observation, path_i, itr_epsilon=None):
        # print("\n\nIn get_action sim_step: {}\n\n".format(sim_step))
        flat_obs = self.observation_space.flatten(observation)

        # calculate action
        mean, log_std = [x[0] for x in self._f_dist([flat_obs])]
        rnd = np.random.normal(size=mean.shape)
        pre_action = rnd * np.exp(log_std) + mean
        # get mean and std for control and state
        # control first then state
        mean_ctrl = mean[:self.action_dim_ctrl]
        mean_obs = mean[self.action_dim_ctrl:]
        log_std_ctrl = log_std[:self.action_dim_ctrl]
        log_std_obs = log_std[self.action_dim_ctrl:]

        # generate noise on action or control when it is adversary
        if self.is_protagonist is not True:
            if self.act_noise:
                action = self.noise_constrain(pre_action, path_i, itr_epsilon)
            elif self.ctrl_noise and self.state_noise:
                # control first then state
                pre_action_ctrl = pre_action[:self.action_dim_ctrl]
                pre_action_obs = pre_action[self.action_dim_ctrl:]
                action_ctrl =\
                    self.noise_constrain(pre_action_ctrl, path_i, itr_epsilon)
                action_obs =\
                    self.noise_constrain(pre_action_obs, path_i, itr_epsilon)
                # action = copy.deepcopy(action_ctrl)
                action = np.append(action_ctrl, action_obs)
            elif self.RARL:
                action = pre_action
                """
                rnd_shape = len(flat_obs)
                pre_action = np.random.normal(size=rnd_shape)
                action = self.noise_constrain(pre_action)
                print("\n\n\nflat_shape: {}; pre: {}; after: {}; "
                      "state: {}\n\n\n".format(rnd_shape, pre_action,
                                               action, flat_obs))
                """
            else:
                raise ValueError
        else:
            action = pre_action

        # test
        if np.any(np.isnan(action)):
            print("\n\n\nGaussian MLP Policy has Nan!!!\n\n\n")

        if not self.is_protagonist:
            if self.state_noise and self.ctrl_noise:
                """
                dict_ctrl = dict(mean=mean_ctrl, log_std=log_std_ctrl)
                dict_obs = dict(mean=mean_obs, log_std=log_std_obs)
                return dict(ctrl_act=action_ctrl, obs_act=action_obs),\
                    dict(ctrl=dict_ctrl, obs=dict_obs)
                """
                return action, dict(mean=mean, log_std=log_std,
                                    ctrl_dim=self.action_dim_ctrl)
            else:
                return action, dict(mean=mean, log_std=log_std)
        else:
            return action, dict(mean=mean, log_std=log_std)

    def noise_constrain(self, temp_pre_val, path_i, itr_epsilon):
        pre_val = copy.deepcopy(temp_pre_val)
        val_dim = len(pre_val)
        # sim_step = path_i

        # calculate epsilon for constraining noise
        """
        if self.eps_grad:
            # start from 1
            sim_step = sim_step + 1
            if self.anneal_type == 1:
                self.epsilon =\
                    self.para_a * math.log(sim_step, math.exp(1)) + self.para_b
            elif self.anneal_type == 2:
                self.epsilon =\
                    math.exp(self.para_a * sim_step + self.para_b)
            elif self.anneal_type == 3:
                self.epsilon =\
                    self.para_a * sim_step + self.para_b
            else:
                raise ValueError
        """
            # print("\n\nsim_step: {}; epsilon: {}".format(sim_step, self.epsilon))

        # https://arxiv.org/pdf/1702.02284.pdf
        if self.norm == 1:
            sample_norm = LA.norm(pre_val, 1)
            if sample_norm > val_dim * itr_epsilon:
                new_val =\
                    val_dim * itr_epsilon * pre_val / (sample_norm + 1e-10)
            else:
                new_val = pre_val
        elif self.norm == 2:
            sample_norm = LA.norm(pre_val, 2)
            if sample_norm > itr_epsilon * np.sqrt(val_dim):
                new_val =\
                    itr_epsilon * np.sqrt(val_dim) * pre_val / (sample_norm + 1e-10)
            else:
                new_val = pre_val
        elif self.norm == 3:
            sample_norm = LA.norm(pre_val, np.inf)
            if np.abs(sample_norm) > itr_epsilon:
                index = np.where(np.abs(pre_val) > itr_epsilon)
                pre_val[index]\
                    = np.sign(pre_val[index]) * itr_epsilon
            new_val = pre_val
        else:
            raise ValueError
            # print("\n\n\nStep: {}; sample_norm: {}; action: {}\n\n\n".format(sim_step, sample_norm, action))
        return new_val

    """
    def get_actions(self, observations):
        # test
        print("\n\n\nHere we use get_actions()\n\n\n")
        flat_obs = self.observation_space.flatten_n(observations)
        means, log_stds = self._f_dist(flat_obs)
        rnd = np.random.normal(size=means.shape)
        pre_actions = rnd * np.exp(log_stds) + means

        # calculate epsilon for get_action
        if self.eps_grad:
            sim_step = sim_step + 1
            self.epsilon =\
                self.para_a * math.log(sim_step, math.exp(1)) + self.para_b

        # add constrain to action for every observation
        if self.is_protagonist is not True:
            act_len = self.action_dim
            for i in np.arange(0, means.shape[0], act_len):
                if self.norm == 1:
                    sub_actions = pre_actions[i:(i + act_len)]
                    sample_norm = LA.norm(sub_actions, 1)
                    pre_actions[i:(i + act_len)] =\
                        self.epsilon * sub_actions / (sample_norm + 1e-8)
                elif self.norm == 2:
                    sub_actions = pre_actions[i:(i + act_len)]
                    sample_norm = LA.norm(sub_actions, 2)
                    pre_actions[i:(i + act_len)] =\
                        np.sqrt(self.epsilon) * sub_actions / (sample_norm + 1e-8)
                elif self.norm == 3:
                    sub_actions = pre_actions[i:(i + act_len)]
                    sample_norm = LA.norm(sub_actions, np.inf)
                    if np.abs(sample_norm) > self.epsilon:
                        index = np.where(np.abs(sub_actions) == sample_norm)
                        sub_actions[index] =\
                            np.sign(sub_actions[index]) * self.epsilon
                    pre_actions[i:(i + act_len)] = sub_actions
                else:
                    raise ValueError
        actions = pre_actions
        return actions, dict(mean=means, log_std=log_stds)
    """

    def get_reparam_action_sym(self, obs_var, action_var, old_dist_info_vars):
        """
        Given observations, old actions, and distribution of old actions, return a symbolically reparameterized
        representation of the actions in terms of the policy parameters
        :param obs_var:
        :param action_var:
        :param old_dist_info_vars:
        :return:
        """
        new_dist_info_vars = self.dist_info_sym(obs_var, action_var)
        new_mean_var, new_log_std_var = new_dist_info_vars["mean"], new_dist_info_vars["log_std"]
        old_mean_var, old_log_std_var = old_dist_info_vars["mean"], old_dist_info_vars["log_std"]
        epsilon_var = (action_var - old_mean_var) / (TT.exp(old_log_std_var) + 1e-8)
        new_action_var = new_mean_var + epsilon_var * TT.exp(new_log_std_var)
        return new_action_var

    def log_diagnostics(self, paths):
        log_stds = np.vstack([path["agent_infos"]["log_std"] for path in paths])
        logger.record_tabular('AveragePolicyStd', np.mean(np.exp(log_stds)))

    @property
    def distribution(self):
        return self._dist
