from rllab.algos.trpo2 import TRPO2
from rllab.baselines.linear_feature_baseline import LinearFeatureBaseline
from rllab.envs.gym_env2 import GymEnv2
from rllab.envs.normalized_env2 import normalize2
from rllab.policies.gaussian_mlp_policy_anneal import GaussianMLPPolicy3
from rllab.policies.gaussian_mlp_policy2 import GaussianMLPPolicy2
from rllab.policies.constant_control_policy2 import ConstantControlPolicy2
import rllab.misc.logger as logger
from rllab.sampler import parallel_sampler2
import matplotlib.pyplot as plt
import numpy as np
from test2 import test_const_adv2, test_rand_adv2, test_learnt_adv2,\
    test_rand_step_adv2, test_step_adv2
import pickle
import argparse
import os
import gym
import math
import random
# from IPython import embed


# Pass arguments ##
parser = argparse.ArgumentParser()
parser.add_argument('--env', type=str, required=True,
                    help='Name of adversarial environment')
parser.add_argument('--adv_name', type=str, default='no_adv',
                    help='DOESNT MATTER FOR THIS BASELINE')
parser.add_argument('--path_length', type=int, default=1000,
                    help='maximum episode length')
parser.add_argument('--layer_size', nargs='+', type=int,
                    default=[64, 64], help='layer definition')
parser.add_argument('--if_render', type=int, default=0,
                    help='Should we render?')
parser.add_argument('--after_render', type=int, default=100,
                    help='After how many to animate')
parser.add_argument('--n_exps', type=int, default=1,
                    help='Number of training instances to run')
parser.add_argument('--n_itr', type=int, default=25,
                    help='Number of iterations of \
                          the alternating optimization')
parser.add_argument('--n_pro_itr', type=int, default=1,
                    help='Number of iterations for the protagonist')
parser.add_argument('--n_adv_itr', type=int, default=1,
                    help='Number of interations for the adversary')
parser.add_argument('--batch_size', type=int, default=10000,
                    help='Number of training samples for each iteration')
parser.add_argument('--save_every', type=int, default=20,
                    help='Save checkpoint every save_every iterations')
parser.add_argument('--n_process', type=int, default=1,
                    help='Number of parallel threads for sampling environment')
parser.add_argument('--adv_fraction', type=float, default=1.0,
                    help='fraction of maximum adversarial force to be applied')
parser.add_argument('--step_size', type=float, default=0.01,
                    help='kl step size for TRPO')
parser.add_argument('--gae_lambda', type=float, default=0.97,
                    help='gae_lambda for learner')
parser.add_argument('--folder', type=str, default=os.environ['HOME'],
                    help='folder to save result in')
parser.add_argument('--baseline', type=int, default=0,
                    help='whether to train baseline')
parser.add_argument('--RARL', type=int, default=0,
                    help='whether to train rarl')
parser.add_argument('--ctrl_noise', type=int, default=0,
                    help='whether adding noises on actions')
parser.add_argument('--act_noise', type=int, default=0,
                    help='whether adding noises on actions')
parser.add_argument('--state_noise', type=int, default=0,
                    help='whether adding noises on states')
parser.add_argument('--epsilon', type=float, default=0.01,
                    help='bound for constraining action sample')
parser.add_argument('--eps_grad', type=int, default=0,
                    help='whether applying gradual change to epsilon')
parser.add_argument('--eps_grad_paras_bound', nargs='+', type=float,
                    default=[0.0001, 0.01],
                    help='bounds for gradual epsilon')
parser.add_argument('--norm', type=int, default=1,
                    help='norm type: {1: l1, 2: l2, 3: inf}')
parser.add_argument('--seed', type=int, default=123456,
                    help='start random seed for settings')
parser.add_argument('--anneal_type', type=int, default=1,
                    help='1: log-linear; 2: exponential; 3: linear')


# Parsing Arguments ##
args = parser.parse_args()

# show args
print('Called with args:')
print(args)

env_name = args.env
adv_name = args.adv_name
path_length = args.path_length
layer_size = tuple(args.layer_size)
ifRender = bool(args.if_render)
afterRender = args.after_render
n_exps = args.n_exps
n_itr = args.n_itr
n_pro_itr = args.n_pro_itr
n_adv_itr = args.n_adv_itr
batch_size = args.batch_size
save_every = args.save_every
n_process = args.n_process
adv_fraction = args.adv_fraction
step_size = args.step_size
gae_lambda = args.gae_lambda
save_dir = args.folder
baseline_flag = args.baseline
RARL = args.RARL
ctrl_noise = args.ctrl_noise
act_noise = args.act_noise
state_noise = args.state_noise
epsilon = args.epsilon
eps_grad = args.eps_grad
eps_grad_paras_bound = args.eps_grad_paras_bound
norm = args.norm
set_seed = args.seed
anneal_type = args.anneal_type

# Initializing summaries for the tests
const_test_rew_summary = []
rand_test_rew_summary = []
step_test_rew_summary = []
rand_step_test_rew_summary = []
adv_test_rew_summary = []
pro_policy_list = []
adv_policy_list = []

# Preparing file to save results in
save_prefix =\
    'env_{}-Exp_{}-Itr_{}-BS_{}-Adv_{}-stp_{}-lam_{}-'\
    'ctrlNoise_{}-actNoise_{}-stateNoise_{}-RARL_{}-Baseline_{}-epsilon_{}-'\
    'epsGrad_{}-epsParaBound_{}-norm_{}-process_{}-{}'.format(
        env_name, n_exps, n_itr, batch_size, adv_fraction, step_size,
        gae_lambda, ctrl_noise, act_noise, state_noise, RARL, baseline_flag,
        epsilon, eps_grad, eps_grad_paras_bound, norm, n_process,
        random.randint(0, 1000000))
save_name = save_dir + '/' + save_prefix + '.p'


def cal_eps_para(l_bound, h_bound, path_length, eps_grad):
    if eps_grad:
        # eps = a * ln(t) + b
        if anneal_type == 1:
            para_b = l_bound
            para_a = (h_bound - para_b) / math.log(path_length, math.exp(1))
            print("\n\neps = {} * ln(t) + {}\n\n".format(para_a, para_b))
        # eps = exp(a * t + b)
        elif anneal_type == 2:
            para_b = math.log(l_bound, math.exp(1))
            para_a =\
                (math.log(h_bound, math.exp(1)) - para_b) / path_length
            print("\n\neps = exp({} * t + {})\n\n".format(para_a, para_b))
        # eps = a * t + b
        elif anneal_type == 3:
            para_b = l_bound
            para_a = (h_bound - para_b) / path_length
            print("\n\neps = {} * t + {}\n\n".format(para_a, para_b))
        else:
            raise ValueError

        return para_a, para_b


para_a, para_b = cal_eps_para(eps_grad_paras_bound[0],
                              eps_grad_paras_bound[1],
                              n_itr, eps_grad)
args.para_a = para_a
args.para_b = para_b
args.eps_grad_paras = [args.para_a, args.para_b]

# Looping over experiments to carry out
for ne in range(n_exps):
    # Initializing the parallel sampler & set seed
    parallel_sampler2.initialize(n_process)
    parallel_sampler2.set_seed(set_seed + ne * n_process * n_itr)

    # Environment definition
    # The second argument in GymEnv defines
    # the relative magnitude of adversary. For testing we set this to 1.0.
    env = GymEnv2(env_name, adv_fraction, args=args,
                  seed=set_seed + ne * n_process * n_itr)

    # print out parameters
    if ctrl_noise and state_noise:
        logger.log('\n\n\nEnv_name: {}\nbnames: {}\n'
                   'adv_act_space_dim: {}\n'
                   'adv_act_space_dim_ctrl: {}\n'
                   'adv_act_space_dim_obs: {}\n'
                   'pro_act_space_dim: {}\n\n\n'.format(
                    env_name, env.bnames,
                    env.adv_action_dim,
                    env.adv_action_space_ctrl.shape,
                    env.adv_action_space_obs.shape,
                    env.pro_action_space.shape))
    else:
        logger.log('\n\n\nEnv_name: {}\nbnames: {}\n'
                   'adv_act_space_dim: {}\n'
                   'pro_act_space_dim: {}\n\n\n'.format(
                    env_name, env.bnames,
                    env.adv_action_space.shape,
                    env.pro_action_space.shape))
    env = normalize2(env)

    # Protagonist policy definition
    pro_policy = GaussianMLPPolicy3(
        env_spec=env.spec,
        hidden_sizes=layer_size,
        is_protagonist=True,
        args=args
    )
    pro_baseline = LinearFeatureBaseline(env_spec=env.spec)

    # Zero Adversary for the protagonist training
    # ConstantControlPolicy is a algorithm written by author
    zero_adv_policy = ConstantControlPolicy2(
        env_spec=env.spec,
        is_protagonist=False,
        constant_val=0.0,
        args=args
    )

    if not baseline_flag:
        env_orig = GymEnv2(env_name, 1.0, args=args)
        env_orig = normalize2(env_orig)
        # Adversary policy definition
        adv_policy = GaussianMLPPolicy2(
            env_spec=env.spec,
            hidden_sizes=layer_size,
            is_protagonist=False,
            args=args
        )
        adv_baseline = LinearFeatureBaseline(env_spec=env.spec)

    # Initializing the parallel sampler & set seed
    # parallel_sampler2.initialize(n_process)
    # parallel_sampler2.set_seed(set_seed + ne * n_process)

    # Optimizer for the Protagonist
    # Changes are made in NPO
    if baseline_flag:
        pro_algo = TRPO2(
            env=env,
            pro_policy=pro_policy,
            adv_policy=zero_adv_policy,
            pro_baseline=pro_baseline,
            adv_baseline=pro_baseline,
            batch_size=batch_size,
            max_path_length=path_length,
            n_itr=n_pro_itr,
            discount=0.995,
            gae_lambda=gae_lambda,
            step_size=step_size,
            is_protagonist=True
        )
    else:
        pro_algo = TRPO2(
            env=env,
            pro_policy=pro_policy,
            adv_policy=adv_policy,
            pro_baseline=pro_baseline,
            adv_baseline=adv_baseline,
            batch_size=batch_size,
            max_path_length=path_length,
            n_itr=n_pro_itr,
            discount=0.995,
            gae_lambda=gae_lambda,
            step_size=step_size,
            is_protagonist=True
        )

    # Optimizer for the Adversary
    if not baseline_flag:
        adv_algo = TRPO2(
            env=env,
            pro_policy=pro_policy,
            adv_policy=adv_policy,
            pro_baseline=pro_baseline,
            adv_baseline=adv_baseline,
            batch_size=batch_size,
            max_path_length=path_length,
            n_itr=n_adv_itr,
            discount=0.995,
            gae_lambda=gae_lambda,
            step_size=step_size,
            is_protagonist=False,
            scope='adversary_optim'
        )

    # Setting up summaries for testing for a specific training instance
    pro_rews = []
    adv_rews = []
    all_rews = []
    if baseline_flag:
        env_orig = env
    const_testing_rews = []
    const_testing_rews.append(test_const_adv2(
        env_orig, pro_policy, path_length=path_length, args=args))
    rand_testing_rews = []
    rand_testing_rews.append(test_rand_adv2(
        env_orig, pro_policy, path_length=path_length, args=args))
    step_testing_rews = []
    step_testing_rews.append(test_step_adv2(
        env_orig, pro_policy, path_length=path_length, args=args))
    rand_step_testing_rews = []
    rand_step_testing_rews.append(test_rand_step_adv2(
        env_orig, pro_policy, path_length=path_length, args=args))
    adv_testing_rews = []
    if baseline_flag:
        adv_testing_rews.append(test_rand_adv2(
            env, pro_policy, path_length=path_length))
    else:
        adv_testing_rews.append(test_learnt_adv2(
            env, pro_policy, adv_policy, path_length=path_length,
            itr_epsilon=eps_grad_paras_bound[0]))

    # Beginning alternating optimization
    for ni in range(n_itr):
        # calculate epsilon for constraining noise
        if eps_grad:
            # start from 1
            sim_step = ni + 1
            if anneal_type == 1:
                itr_epsilon =\
                    para_a * math.log(sim_step, math.exp(1)) + para_b
            elif anneal_type == 2:
                # print("\nstep: {}; a: {}; b: {}\n".format(sim_step, para_a, para_b))
                itr_epsilon =\
                    math.exp(para_a * sim_step + para_b)
            elif anneal_type == 3:
                itr_epsilon =\
                    para_a * sim_step + para_b
            else:
                raise ValueError

        logger.log('\n\n\n#### Exp No: #{} | Global Itr: #{} | '
                   'n_pro_itr: #{} | Eps: {} ####\n\n\n'.format(
                    ne, ni, args.n_pro_itr, itr_epsilon))
        # Train protagonist
        pro_algo.train(itr_epsilon)
        pro_rews += pro_algo.rews
        all_rews += pro_algo.rews
        logger.log('Protag Reward: {}'.format(np.array(pro_algo.rews).mean()))
        # Do not train Adversary ONLY when there is state_noise
        if args.baseline:
            logger.log('Only baseline, do not train adversary')
        else:
            adv_algo.train(itr_epsilon)
            adv_rews += adv_algo.rews
            all_rews += adv_algo.rews
            logger.log('Advers Reward: {}'.format(np.array(adv_algo.rews).mean()))
        # Test the learnt policies
        const_testing_rews.append(test_const_adv2(
            env, pro_policy, path_length=path_length, args=args))
        rand_testing_rews.append(test_rand_adv2(
            env, pro_policy, path_length=path_length, args=args))
        step_testing_rews.append(test_step_adv2(
            env, pro_policy, path_length=path_length, args=args))
        rand_step_testing_rews.append(test_rand_step_adv2(
            env, pro_policy, path_length=path_length, args=args))
        if baseline_flag:
            adv_testing_rews.append(test_rand_adv2(
                env, pro_policy, path_length=path_length))
        else:
            adv_testing_rews.append(
                test_learnt_adv2(env, pro_policy, adv_policy,
                                 path_length=path_length,
                                 itr_epsilon=itr_epsilon))

        if ni % afterRender == 0 and ifRender is True:
            test_const_adv2(env, pro_policy,
                            path_length=path_length, n_traj=1, render=True)

        if (ni + 1) % save_every == 0:
            if baseline_flag:
                pickle.dump({'args': args,
                             'pro_policy': pro_policy_list,
                             'zero_test': const_test_rew_summary,
                             'rand_test': rand_test_rew_summary,
                             'step_test': step_test_rew_summary,
                             'rand_step_test': rand_step_test_rew_summary,
                             'iter_save': ni,
                             'exp_save': ne,
                             'adv_test': adv_test_rew_summary},
                            open(save_name + '.temp', 'wb'))
            else:
                # SAVING CHECKPOINT INFO
                pickle.dump({'args': args,
                             'pro_policy': pro_policy_list,
                             'adv_policy': adv_policy_list,
                             'zero_test': const_test_rew_summary,
                             'rand_test': rand_test_rew_summary,
                             'step_test': step_test_rew_summary,
                             'rand_step_test': rand_step_test_rew_summary,
                             'iter_save': ni,
                             'exp_save': ne,
                             'adv_test': adv_test_rew_summary},
                            open(save_name + '.temp', 'wb'))

    # Shutting down the optimizer
    pro_algo.shutdown_worker()
    if not baseline_flag:
        adv_algo.shutdown_worker()

    # Updating the test summaries over all training instances
    const_test_rew_summary.append(const_testing_rews)
    rand_test_rew_summary.append(rand_testing_rews)
    step_test_rew_summary.append(step_testing_rews)
    rand_step_test_rew_summary.append(rand_step_testing_rews)
    adv_test_rew_summary.append(adv_testing_rews)

# SAVING INFO
if baseline_flag:
    pickle.dump({'args': args,
                 'pro_policy': pro_policy_list,
                 'zero_test': const_test_rew_summary,
                 'rand_test': rand_test_rew_summary,
                 'step_test': step_test_rew_summary,
                 'rand_step_test': rand_step_test_rew_summary,
                 'iter_save': ni,
                 'exp_save': ne,
                 'adv_test': adv_test_rew_summary},
                open(save_name, 'wb'))
else:
    # SAVING CHECKPOINT INFO
    pickle.dump({'args': args,
                 'pro_policy': pro_policy_list,
                 'adv_policy': adv_policy_list,
                 'zero_test': const_test_rew_summary,
                 'rand_test': rand_test_rew_summary,
                 'step_test': step_test_rew_summary,
                 'rand_step_test': rand_step_test_rew_summary,
                 'iter_save': ni,
                 'exp_save': ne,
                 'adv_test': adv_test_rew_summary},
                open(save_name, 'wb'))

logger.log('\n\n\n#### DONE ####\n\n\n')
